// 数据库连接配置
module.exports = {
  host: 'localhost',
  user: 'root', // 数据库账号
  password: '123456', // 数据库密码
  database: 'demo_weekly',
  port: 3306,
  multipleStatements: true
}