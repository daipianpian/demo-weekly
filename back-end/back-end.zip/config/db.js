// 数据库连接配置
module.exports = {
  host: 'localhost',
  user: 'root',
  password: '123456',
  database: 'demo_weekly',
  port: 3306,
  multipleStatements: true
}